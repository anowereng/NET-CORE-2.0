﻿namespace NeelSessionExample.Utility
{
    public class Test
    {
        private SessionUtility session;

        public Test()
        {
            TestMethod(); 
           // _context = context;
           // _currentUser = userService.GetUser();
        }

        public void TestMethod()
        {
            
        }
    }
}
